import repository.DatabaseSetup;

public class Main {
    public static void main(String[] args) {
        DatabaseSetup.inicializarBanco();
    }
}