package app.ui;

import javafx.beans.binding.Bindings;
import javafx.geometry.Rectangle2D;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Region;
import javafx.scene.shape.Circle;

/**
 * Deixa um ImageView como foto de perfil redonda (estilo WhatsApp).
 *
 * O recorte circular é aplicado no CONTAINER da foto (o StackPane do FXML),
 * que tem tamanho fixo, e o ImageView é forçado a preencher esse container.
 * Assim a foto e o círculo sempre coincidem, mesmo que outro trecho do código
 * tente mudar o tamanho ou o recorte do ImageView.
 *
 * Uso (no initialize() do controlador):
 *     FotoCircular.aplicar(fotoPerfil);
 *     FotoCircular.aplicar(fotoMiniatura);
 */
public final class FotoCircular {

    /** Classe CSS que tira o fundo laranja quando existe foto (ver estilo.css). */
    private static final String CLASSE_COM_FOTO = "com-foto";

    private FotoCircular() {}

    public static void aplicar(ImageView view) {
        Region caixa = (view.getParent() instanceof Region r) ? r : null;
        double tamanho = (caixa != null && caixa.getPrefWidth() > 0)
                ? caixa.getPrefWidth()
                : view.getFitWidth();

        // 1) O ImageView ocupa exatamente o tamanho do círculo, sem manter proporção
        //    (o corte quadrado central é feito pelo viewport, mais abaixo).
        view.setPreserveRatio(false);
        view.setSmooth(true);
        view.setFitWidth(tamanho);
        view.setFitHeight(tamanho);

        // Se outro código mexer nisso depois, volta ao valor certo.
        view.fitWidthProperty().addListener((o, a, n) -> {
            if (n.doubleValue() != tamanho) view.setFitWidth(tamanho);
        });
        view.fitHeightProperty().addListener((o, a, n) -> {
            if (n.doubleValue() != tamanho) view.setFitHeight(tamanho);
        });
        view.preserveRatioProperty().addListener((o, a, n) -> {
            if (n) view.setPreserveRatio(false);
        });

        // 2) O recorte circular fica no container, acompanhando o tamanho dele.
        if (caixa != null) {
            view.setClip(null);
            // Se algum código colocar um recorte próprio no ImageView, ele é removido.
            view.clipProperty().addListener((o, a, n) -> {
                if (n != null) view.setClip(null);
            });

            Circle circulo = new Circle();
            circulo.centerXProperty().bind(caixa.widthProperty().divide(2));
            circulo.centerYProperty().bind(caixa.heightProperty().divide(2));
            circulo.radiusProperty().bind(
                    Bindings.min(caixa.widthProperty(), caixa.heightProperty()).divide(2));
            caixa.setClip(circulo);
        } else {
            view.setClip(new Circle(tamanho / 2, tamanho / 2, tamanho / 2));
        }

        // 3) Recorta a imagem em quadrado no centro e marca o container "com foto".
        view.imageProperty().addListener((obs, antiga, nova) -> atualizar(view, caixa, nova));
        atualizar(view, caixa, view.getImage());
    }

    private static void atualizar(ImageView view, Region caixa, Image img) {
        if (caixa != null) {
            caixa.getStyleClass().remove(CLASSE_COM_FOTO);
            if (img != null) caixa.getStyleClass().add(CLASSE_COM_FOTO);
        }

        if (img == null) {
            view.setViewport(null);
            return;
        }
        // Imagem carregada em segundo plano: espera terminar para saber o tamanho real.
        if (img.getProgress() < 1.0) {
            img.progressProperty().addListener((o, a, progresso) -> {
                if (progresso.doubleValue() >= 1.0 && view.getImage() == img) {
                    atualizar(view, caixa, img);
                }
            });
            return;
        }

        double largura = img.getWidth();
        double altura = img.getHeight();
        double lado = Math.min(largura, altura);
        view.setViewport(new Rectangle2D((largura - lado) / 2, (altura - lado) / 2, lado, lado));
    }
}